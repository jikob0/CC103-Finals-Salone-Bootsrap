<p>It is a free HTML CSS template by <a href="https://templatesjungle.com/" target="_blank">TemplatesJungle.com</a></p>
<p>You can use this template as a starter template and start building as you require.</p>

<p>The code is consistent and can be easily maintained as we have followed a good coding standards. We want everyone to easily understand it and modify it according to their requirement. As the main goal of providing these templates is to give you something to work on before even starting.</p>


<h2>FREE FOR BOTH PERSONAL AND COMMERCIAL USE</h2>

<p>This HTML Template is provided by TemplatesJungle.com and is free to use in both personal and commercial projects as long as you don't remove our credit link in the footer.</p>

<p>However, you can remove the credit link by paying for No Attribution version of the template.</p>


<h2>RIGHTS</h2>

<p>You are allowed to use it in your personal projects and commercial projects.</p>

<p>You can modify and sell it to your clients.</p>


<h2>PROHIBITIONS</h2>

<p>You cannot remove the credit link which links back to templatesjungle.com.</p>

<p>You are not permitted to resell or redistribute (paid or free) as it is. </p>

<p>You cannot use it to build premium templates, themes or any other goods to be sold on marketplaces.</p>

<p>If you want to share the free resource in your blog, you must point it to original TemplatesJungle.com resource page. </p>

<p>You cannot host the download file in your website.</p>


<h2>SUPPORT</h2>

<p>You can contact us to report any bugs and errors in the template. We will try and fix them immediately although it's a free resource.</p>

<p>Feel free to let us know about what you want to see in the future downloads. We will definitely give it a thought while creating our next freebie.</p>


<h2>CREDITS & REFERENCES<h2>

<p><a href="https://getbootstrap.com/" target="_blank">https://getbootstrap.com/</a></p>

<h3>Stock Photos</h3>
<p><a href="https://unsplash.com/" target="_blank">https://unsplash.com/</a></p>
<p><a href="https://www.freepik.com/" target="_blank">https://www.freepik.com/</a></p>
<p><a href="https://www.pexels.com/" target="_blank">https://www.pexels.com/</a></p>

<h3>Fonts</h3>
<p>Google fonts</p>
<p><a href="https://fonts.google.com/" target="_blank">https://fonts.google.com/</a></p>

<h3>Icons</h3>
<p><a href="https://icomoon.io/" target="_blank">https://icomoon.io/</a></p>

<h3>JQuery Plugins</h3>

<p>Swiper Slider - <a href="https://swiperjs.com/" target="_blank">https://swiperjs.com/</a></p>
<p>Slick Slider - <a href="https://kenwheeler.github.io/slick/" target="_blank">https://kenwheeler.github.io/slick/</a></p>
<p>Chocolat.js – a Free Lightbox Plugin -<a href="http://chocolat.insipi.de/" target="_blank">http://chocolat.insipi.de/</a></p>
<p>Magnific Lightbox - <a href="https://github.com/dimsemenov/Magnific-Popup" target="_blank">https://github.com/dimsemenov/Magnific-Popup</a></p>

<p>Thanks for downloading from TemplatesJungle.com !</p>


